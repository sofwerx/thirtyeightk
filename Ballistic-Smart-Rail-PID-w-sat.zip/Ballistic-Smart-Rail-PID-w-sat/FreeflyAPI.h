// Freefly API Header

#ifndef FREEFLYAPI_h
#define FREEFLYAPI_h


extern "C"{
#include "QX_Protocol_App.h"
#include "stdint.h"
}


#endif

